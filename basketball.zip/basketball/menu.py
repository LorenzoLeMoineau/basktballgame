import pygame
import math
from constant import *
from physic import *

#load the ball, game and player image
ballimg = pygame.image.load("data/ball.png")
gameimg = pygame.image.load("data/game.jpg")
playerimg = pygame.image.load("data/player.png")
velocity=10
angle=45

#convert the coordinates in the classic physical coordinate system in meters in the reverse Pygame coordinate system in pixels
def chgtrepere(xp,yp):
    xs=xp+marge
    ys=(c_ys-yp)-marge
    return xs,ys

#create Main Menu
def ShowMainMenu():
    screen.fill(black) #clear screen
    # load an img as Main Menu Screen
    mainmenuimg = pygame.image.load("data/MainMenu.jpg")
    screen.blit(mainmenuimg,(0, 0))

#create Rules interface
def ShowRules():
    screen.fill(black) #clear screen
    # load an img as Rules Screen
    rulesimg = pygame.image.load("data/Rules.jpg")
    screen.blit(rulesimg,(0, 0))

#create victory interface
def ShowVictory():
    screen.fill(black) #clear screen
    # load an img as Victory Screen
    victoryimg = pygame.image.load("data/victory.jpg")
    screen.blit(victoryimg,(0, 0))

#create game interface
def game(screen):
    screen.blit(gameimg,(0, 0))


#draw the line red of the angle shoot
def lineangle(xp,yp,angle,velocity):
    global coeffm2pix,screen
    xp = xp * coeffm2pix
    yp = yp * coeffm2pix
    xs, ys = chgtrepere(xp, yp)
    norme=velocity+15
    angle=angle*0.01744444
    x2s=xs+math.cos(angle)*norme
    y2s=ys-math.sin(angle)*norme
    pygame.draw.line(screen, rouge, (xs, ys), (x2s,y2s),4)

#show a player
def player():
    global coeffm2pix,xplayer,yplayer,screen
    xp = xplayer * coeffm2pix
    yp = yplayer * coeffm2pix
    xs, ys = chgtrepere(xp, yp)
    screen.blit(playerimg, (xs-30, ys))

#show speed and angle
def PlaceTxt(angle,velocity):
    global screen,police
    NbVelocity = police.render(str(velocity), 2, white)
    screen.blit(NbVelocity, (232, 122))

    NbAngle = police.render(str(angle), 2, white)
    screen.blit(NbAngle, (312, 122))

#when we click a button, it change the state
def ChangeState(state):
    # get mouse position
    posmouse = pygame.mouse.get_pos()
    posmousex = posmouse[0]
    posmousey = posmouse[1]
    #if you are in the main menu check click buttons
    if (state == "Menu"):
        if (213<posmousex<427 and 152<posmousey<212):
            return "Play"
        if (213<posmousex<427 and 225<posmousey<284):
            return "RulesMenu"
        if (213<posmousex<427 and 291<posmousey<351):
            return "Quit"
    if (state == "RulesMenu"):
        if (418<posmousex<631 and 413<posmousey<471):
            return "Menu"
    if (state == "RulesGame"):
        if (418<posmousex<631 and 413<posmousey<471):
            return "Play"
    if (state == "Play"):
        if (10<posmousex<75 and 8<posmousey<74):
            return "RulesGame"
        if (83<posmousex<154 and 8<posmousey<74):
            return "Menu"
        if (199<posmousex<374 and 29<posmousey<70):
            return "Shoot"
    if (state == "Victory"):
        if (213<posmousex<427 and 152<posmousey<212):
            return "Quit"
    # return the same state if there is no changement state
    return state

#draw the ball from the physical coordinates of the motor
def ball(xp,yp):
    global coeffm2pix,screen
    xp = xp * coeffm2pix
    yp = yp * coeffm2pix
    xs, ys = chgtrepere(xp, yp)
    rayon=c_rayonball*coeffm2pix
    pygame.draw.circle(screen, (153, 204, 255),(xs, ys), rayon)
    screen.blit(ballimg, (xs-9, ys-10))
    pygame.display.update()
