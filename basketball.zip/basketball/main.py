import pygame
from physic import *
from menu import *

#all variables and constant is imported here
from constant import *

run = True
while run == True:
    pygame.display.update()
    if state=="Menu":
        ShowMainMenu()
    if (state == "RulesMenu"):
        ShowRules()
    if (state == "Quit"):
        pygame.quit()
        exit(0)
    if state=="Play":
        game(screen)
        PlaceTxt(angle,velocity)  # write speed and angle
        player()
        ball(x0, y0)
        lineangle(x0, y0, angle, velocity)

        pygame.display.update()
    if (state == "RulesGame"):
        ShowRules()
    if (state == "Shoot"):
        state="Play"
        win=ShootBall(velocity,x0, y0,angle)
        if (win==1):
            state="Victory"
    if (state == "Victory"):
        ShowVictory()

    #check the event
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN and state=="Play":
            if event.key == pygame.K_UP:
                if (1<=velocity<20): # speed must be between 1 and 20
                    velocity=velocity+1
            if event.key == pygame.K_DOWN:
                if (1 < velocity < 21):
                    velocity = velocity - 1
            if event.key == pygame.K_RIGHT:
                if (1<=angle<120):  # speed must be between 1 and 120
                    angle=angle+1
            if event.key == pygame.K_LEFT:
                if (1<angle<121):
                    angle=angle-1
        if event.type == pygame.QUIT:
                run = False
                pygame.quit()
    # if user click then we check if we need to change screen or launch an action
    if event.type == pygame.MOUSEBUTTONDOWN:
        state = ChangeState(state)