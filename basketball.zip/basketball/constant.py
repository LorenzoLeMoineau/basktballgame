import pygame
import math
import random

# constant
c_xs=640 #length screen in pixel
c_ys=480 #width screen in pixel
black=(0,0,0)
white=(250,250,250)
rouge = (255, 0, 0)
#constant
marge=20 #margin of the screen
c_hterrainp=c_ys-(marge*2) #ceiling height in pixels
c_g=9.81 #gravitational constant
c_xs=640 #length screen in pixel
c_ys=480 #width screen in pixel
c_hr=8 #ceiling height in meters
c_lterrain=(c_hr*(c_xs-marge*2))/c_hterrainp #length of the basketball court in pixels wich represent 11.63 meters
coeffpix2m=c_hr/c_hterrainp #pixel to meter conversion coefficient
coeffm2pix=c_hterrainp/c_hr #meter to pixel conversion factor
c_amortissement=0.5 #damping coefficient
c_seuilv=0.9 #speed threshold at which the ball stops
c_rayonball=0.15 #ball radius in meters
firstpointxpanierp=c_lterrain-0.45 #coordinates of point x to the left of the basket hoop
firstpoinytpanierp=3.05 #coordinate of the point y to the left of the basketball hoop
epaisseurpanierp=0.02 #thickness of the basketball hoop in meters
firstpointypanierp=3.05 #coordinate of the point y to the left of the basketball hoop

#creation of a window called BASKETBALL_GAME of the size of the length and the height
pygame.init()
pygame.display.set_caption("BASKETBALL_GAME")
screen = pygame.display.set_mode((c_xs, c_ys))
state="Menu"

#global variable
t=0
x0=2+random.randint(0,4)  #initial x position in random meter
#x0=2+4 #test to do during the presentation
y0=2
xplayer=x0
yplayer=y0
police = pygame.font.SysFont("arialblack", 20)