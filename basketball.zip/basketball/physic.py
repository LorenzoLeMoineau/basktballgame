from constant import *
from menu import *
import pygame
import math
import time
global screen

#variable
flag=0 #no shoot hoop yet

#convert the coordinates in the classic physical coordinate system in meters in the reverse Pygame coordinate system in pixels
def chgtrepere(xp,yp):
    xs=xp+marge
    ys=(c_ys-yp)-marge
    return xs,ys

#calculates the speed of a vector according to its angle, its component in x and y and time t
def vitesse(angle,vi,t):
    global c_g
    vx=vi*math.cos(angle)
    vy=-c_g*t+vi*math.sin(angle)
    return vx,vy

#Transform an AB vector into a BA vector
def vecteuroppose(x,y):
    return -x,-y

#calculate the norm of a vector
def norme(x,y):
    norm=math.sqrt(x**2+y**2)
    return norm

#calculate the scalar product
def scalaire(x1,y1,x2,y2):
    return x1*x2+y1*y2

#calculate the angle in radians between two vectors
def angleradian(x1,y1,x2,y2):
    dot = x1 * x2 + y1 * y2  # dot product between [x1, y1] and [x2, y2]
    det = x1 * y2 - y1 * x2  # determinant
    angle = math.atan2(det, dot)  # atan2(y, x) or atan2(sin, cos)
    return angle

#rotate vector by some given angle
def rotationvecteur(x,y,angle):
    xf=x*math.cos(angle)-y*math.sin(angle)
    yf=x*math.sin(angle)+y*math.cos(angle)
    return round(xf,4),round(yf,4)

#calculate the angle of reflection after a collision
def anglereflexion(nx,ny,vx,vy):
    nrx,nry=rotationvecteur(nx,ny,-math.pi/2)
    angler=angleradian(vx,vy,nrx,nry)
    anglecorrection=angleradian(1,0,nrx,nry)
    return angler+anglecorrection

#calculate the surface norm after a collision
def collision(x,y,vy):
    global flag
    nx=0
    ny=0
    if(y<=c_rayonball): #floor
        nx=0
        ny=1
        y=c_rayonball
    if (x>=c_lterrain-c_rayonball): #right wall
        nx=-1
        ny=0
        x=c_lterrain-c_rayonball
    if (x<=c_rayonball): #left wall
        nx=1
        ny=0
        x=c_rayonball
    if (y>=c_hr-c_rayonball): #ceiling
        nx=0
        ny=-1
        y=c_hr-c_rayonball
    bornex1=firstpointxpanierp - c_rayonball
    bornex2=firstpointxpanierp+c_rayonball
    borney1=firstpointypanierp - c_rayonball
    borney2=firstpointypanierp+c_rayonball
    vectxpb=firstpointxpanierp - x
    vectypb=firstpointypanierp - y
    if (bornex1<=x and bornex2>=x and borney1<=y and borney2>=y): #collision of the basketball hoop
        if (norme(vectxpb, vectypb)<=c_rayonball):
            vx,vy=vecteuroppose(vectxpb,vectypb)
            angle1=angleradian(1,0,vx,vy)
            nx=math.cos(angle1)
            ny=math.sin(angle1)
            x=firstpointxpanierp+0.16*math.cos(angle1)
            y=firstpointypanierp++0.16*math.sin(angle1)
    if (firstpointxpanierp+0.10<x<c_xs-marge-0.10 and firstpointypanierp-0.1<y<firstpointypanierp+0.1 and flag==0): #determine if the shoot is ok
        if (vy<=0):
            flag=1
        elif(vy>0):
            flag=-1
    return nx,ny,x,y,flag

#calculate the trajectory of a projectile
def projectile(xi,yi,angle,vi,t):
    x=vi*math.cos(angle)*t+xi
    y=-c_g*(t**2/2)+vi*math.sin(angle)*t+yi
    return x,y

#takes a shot as long as the ball does not hit a surface
def shoot(v0,angle,x0,y0):
    global screen, police, xplayer, yplayer
    t=0
    choc=0
    while choc==0: #as long as there is no collision, the ball falls
        time.sleep(0.01)
        t = t + 0.01
        xp,yp=projectile(x0,y0,angle,v0,t)
        vx,vy=vitesse(angle, v0, t)
        # reset screen game
        game(screen)
        player()
        ball(xp, yp)
        nx,ny,xp,yp,flag=collision(xp,yp,vy) #determine if there is a collision
        choc=norme(nx,ny)
    return vx,vy,xp,yp,nx,ny

#function of the entire shoot with rebounds
def ShootBall(vi,xi,yi,angledegre):
    global screen,police,xplayer,yplayer
    t=0
    v0=vi
    x0=xi
    y0=yi
    ang=angledegre*0.01744444 #angle initial in radian
    while (v0>c_seuilv):
        vx,vy,xp,yp,nx,ny=shoot(v0,ang,x0,y0)
        t = 0
        vc = norme(vx, vy)
        v0 = vc * c_amortissement
        anglereflex = anglereflexion(nx,ny,vx,vy)
        x0 = xp
        y0 = yp
        ang=anglereflex
    if (flag==1):
        return 1
    return 0



